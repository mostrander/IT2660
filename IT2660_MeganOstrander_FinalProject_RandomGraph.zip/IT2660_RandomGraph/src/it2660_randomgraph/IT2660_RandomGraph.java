/*
 * Goal: To produce a randomly generated graph containing 100,000 Nodes/values
 *      and using the following methods to search for a user specified value:
        Breadth-First, Depth-First, and Dijkstra's Algorithm
 */
package it2660_randomgraph;

import java.util.Scanner;

/**
 *
 * @author Megan Ostrander
 */
public class IT2660_RandomGraph {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner keyboard = new Scanner(System.in);
        int response = 0;
        int nodes = 0;
        int search = 0;
        int total = 0;
        
        //Initialize a Node array named "graph" & Node object "vertex"
        SimpleGraph graph = new SimpleGraph(1); //temp setup to silence program errors
        Listing vertex;
        
        System.out.println("Please select an action to take."
                    + "\n1. Create a new graph."
                    + "\n2. Add value(s) to graph."
                    + "\n3. Perform a DFT search of the graph."
                    + "\n4. Perform a BFT search of the graph."
                    + "\n5. Perform a Dijkstra search of the graph."
                    + "\n6. Print all nodes in the graph."
                    + "\n7. Print all connections in the graph."
                    + "\n8. Exit program.");
            response = keyboard.nextInt();
        
        while (response != 8)
        {
//            System.out.println("Please select an action to take."
//                    + "\n1. Create a new graph."
//                    + "\n2. Add value(s) to graph."
//                    + "\n3. Perform a DFT search of the graph."
//                    + "\n4. Perform a BFT search of the graph."
//                    + "\n5. Perform a Dijkstra search of the graph."
//                    + "\n6. Print all nodes in the graph."
//                    + "\n7. Print all connections in the graph."
//                    + "\n8. Exit program.");
//            response = keyboard.nextInt();
            
            switch(response)
            {
                case 1:
                    System.out.println("Please specify size of graph (Recommended: 1000 nodes or less):");
                    nodes = keyboard.nextInt();
                    total = nodes;
                    
                    System.out.println("Creating new graph with " + nodes + " nodes.");
                    graph = new SimpleGraph(nodes);
                    System.out.println("Graph is ready for adding nodes.");
                    break;
                case 2:
                    System.out.println("Please enter number of nodes to add to graph.");
                    nodes = keyboard.nextInt();
                    if(nodes < 1)
                    {
                        System.out.println("Cannot add zero or negative nodes to the graph!"
                                + "\nPlease try again!");
                    }
                    else if(nodes == 1)
                    {
                        System.out.println("Adding single node to the graph.");
                        graph.addBulkVertices(nodes);

                        //graph.establishConnections();
                    }
                    else
                    {
                        System.out.println("Adding multiple nodes to the graph.");
                        graph.addBulkVertices(nodes);

                        //graph.establishConnections();
                    }
                    
                    break;
                case 3:
                    
                    System.out.println("Please enter a value to search for: ");
                    search = keyboard.nextInt();
                    
                    if(total > 1000)
                    {
                        System.out.println("\nBeginning DFT search for the value " + search + ".");
                        System.out.println("This may take a few minutes...");
                        graph.DFTSearch(0, search); //search graph for value
                    }
                    else
                    {
                        System.out.println("\nBeginning DFT search for the value " + search + ".");
                        graph.DFTSearch(0, search); //search graph for value
                    }
                    
                    break;
                case 4:
                    System.out.println("Please enter a value to search for: ");
                    search = keyboard.nextInt();
                    
                    if(total > 1000)
                    {
                        System.out.println("\nBeginning BFT search for the value " + search + ".");
                        System.out.println("This may take a few minutes...");
                        graph.BFTSearch(0, search); //search graph for value
                    }
                    else
                    {
                       System.out.println("\nBeginning BFT search for the value " + search + ".");
                        graph.BFTSearch(0, search); //search graph for value 
                    }
                    
                    break;
                case 5:
                    
                    System.out.println("\nTesting Dijkstra Search now.");
                    graph.DijkstraSearch(0);
                    break;
                case 6:
                    
                    System.out.println("Displaying all nodes in current graph: ");
                    graph.printGraphVertices();
                    break;
                case 7:
                    if(total <= 100)
                    {
                        System.out.println("Displaying all established connections in current graph.");
                        graph.printConnections();
                    }
                    else
                    {
                        System.out.println("Too many nodes in graph to display individual connections."
                                + "\nDisplaying total number of connections in graph.");
                        graph.getTotalConnections();
                    }
                    
                    break;
                case 8:
                    System.out.println("Exiting program. Thank you and have a good day!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid input. Please try again.");
                    break;
                    
            }
            
            System.out.println("\nPlease select an action to take."
                    + "\n1. Create a new graph."
                    + "\n2. Add value(s) to graph."
                    + "\n3. Perform a DFT search of the graph."
                    + "\n4. Perform a BFT search of the graph."
                    + "\n5. Perform a Dijkstra search of the graph."
                    + "\n6. Print all nodes in the graph."
                    + "\n7. Print all connections in the graph."
                    + "\n8. Exit program.");
            response = keyboard.nextInt();
        }
        

//        //Initialize a Node array named "graph" & Node object "vertex"
//        SimpleGraph graph = new SimpleGraph(1000);
//        Listing vertex;
        
//        //test addBulkValues method for SimpleGraph
//        System.out.println("Adding 99 values to the graph");
//        graph.addBulkVertices(900);
//        
//        System.out.println("\nWill attempt to add 120 values to existing graph.");
//        graph.addBulkVertices(120);
//        
//        //test addValue method for SimpleGraph
//        System.out.println("\nWill attempt to add a single value to existing graph.");
//        graph.addVertex(1); //will always have a 1 in the node list!
//        
////        //test: print the array values
//        System.out.println();
//        //graph.printGraphVertices();
//        
//        //test of establishing connections between vertices
//        System.out.println("Establishing connections between vertices in graph");
//        graph.establishConnections();
//        
//        //test for printing connections
//        System.out.println("\nWill attempt to print list of connections now..."
//                + "\n0 = No connection"
//                + "\n1 = Connection Found");
        //graph.printConnections();
//        
//        
        //test for DFT exhaustive method
        //System.out.println("\nBeginning exhaustive DFT search of all connections in graph.");
        //graph.DFT(); //base exhaustive search WITHOUT search criteria
        
        //test for DFT search method
//        int search = graph.getVertexValue(3); //selects value I KNOW is in graph
//        
//        System.out.println("\nBeginning DFT search for the value " + search + ".");
//        graph.DFTSearch(0, search); //search graph for value
        
        //now, use a value I DOUBT is in the graph.
//        System.out.println("\nBeginning DFT search for the value 9999.");
//        graph.DFTSearch(0, 9999);
//        
//        //test of BFT exhaustive method
//        System.out.println("\nBeginning exhaustive BFT search of all connections in graph.");
        //graph.BFT(0); //base exhaustive search WITHOUT search criteria
        
        //test of BFT search method
//        search = graph.getVertexValue(8); //selects value I KNOW is in graph
//        
//        System.out.println("\nBeginning BFT search for the value " + search + ".");
//        graph.BFTSearch(0, search); //search graph for value
        
        
        
        /* Now I just need to figure out the weight search!
        Need to implement the search methods in the SimpleGraph class too! 
        Probably should figure out how to deal with weights too... */
        
        //test of printWeight method from edgeWeight array   
//        System.out.println("\nTesting the connections and weights...");
//        System.out.println("Should ONLY print the weights of EXISTING edges:");
//        graph.printWeight();
        
        //test of individual getWeight calls
        //Note: Make sure ou use array values! (i.e. if array length = 10, DONT USE 10!!
//        System.out.println("\nTesting individual connections if they exist.");
//        graph.getWeight(0, 100);
//        graph.getWeight(9, 5);
//        graph.getWeight(20, 8);
//        graph.getWeight(0, 10);
//        graph.getWeight(40, 1);
//        graph.getWeight(77, 999);
//        graph.getWeight(765, 999);
//        graph.getWeight(244, 999);
//        graph.getWeight(766, 979);
//        graph.getWeight(388, 799);
//        graph.getWeight(69, 89);
//        graph.getWeight(47, 253);

//
//        //Testing for the Dijkstra's algorithm
//        System.out.println("\nTesting Dijkstra Search");
//        graph.DijkstraSearch(0);
    }//End of main method

    
}//End of the program
