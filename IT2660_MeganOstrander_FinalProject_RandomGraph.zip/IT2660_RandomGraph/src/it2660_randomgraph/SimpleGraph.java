/*
 * To hold the random data for the graph. Also includes random weight values
        for the Dijkstra's Algorithm
 */
package it2660_randomgraph;

import java.util.Random;
import java.util.*;

/**
 *
 * @author Megan Ostrander
 */
public class SimpleGraph {
    
    Listing [] vertex; //initializes an array of listing objects
    int [][] edge; //initializes an array to hold ALL connections
    int [][] edgeWeight; //holds weights for connections
    int [][] minDistance; //array that holds values visited during Dijkstra's Algorithm search
    
    int max, numberOfVertices, current; //used to track nodes in array vertex
    private int weight; //Holds random weight of node
    int totalConnections;
    
    Random number = new Random(); //Initializes random generator
    
    
    public SimpleGraph(int number)
    {
        vertex = new Listing[number]; //uses number as array length
        edge = new int[number][number];
        edgeWeight = new int[number][number];
        max = number;
        numberOfVertices = 0; //no vertices in array yet!
        current = 0;
        totalConnections = 0; //holds total number of connections in graph
    }
    
    
    //method for adding values to the array
    //bulk add value method; "number" is number of values to add
    public void addBulkVertices(int number)
    {
        Listing node;
        
        //if the value passed to method is equal or less than zero, inform user
        if(number <= 0)
        {
            System.out.println("Cannot add " + number + " values to the graph!");
        }
        
        //if adding new values goes over max size of array, inform user
        else if((number + numberOfVertices) > max)
        {
            System.out.println("Unable to add " + number + " values to the graph."
                    + "\nGraph can currently hold " + max + " values."
                    + "\nNumber of values in the graph: " + numberOfVertices);
            
            System.out.println("Please add fewer values, or create a new graph!");
        }
        else if(number == 1)
        {
            System.out.println("Adding node to the graph now.");
                node = new Listing();
                vertex[current] = node;
                numberOfVertices++;
                current++;
                
                establishConnections();
        }
        else
        {
            //Assign node objects to the array
            for(int i = 0 ; i < number; i++)
            {

                node = new Listing();
                vertex[current] = node;
                numberOfVertices++;
                current++;
            }
            establishConnections();
        }
        
    }//end of addBulkValues method
    
    
    //method for adding single values at a time
    public void addVertex(int number)
    {
        Listing node = new Listing(number);
        

        //if adding new values goes over max size of array, inform user
        if(numberOfVertices == max)
        {
            System.out.println("Unable to add value to the graph."
                    + "\nGraph can currently hold " + max + " values."
                    + "\nNumber of values in the graph: " + numberOfVertices);
            
            System.out.println("Create a new graph to accommodate the new value.");
        }
        else
        {
                vertex[current] = node;
                numberOfVertices++;
                current++;
        }
    }//edge of addVertex method
    
    //create 
    private boolean insertEdge(int fromVertex, int toVertex)
    {
        if(vertex[fromVertex] == null || vertex[toVertex] == null)
        {
            return false;
        }
        else if(vertex[fromVertex].getConnections() > vertex[fromVertex].getAllowed())
        {
            return false;
        }
        else
        {
            //assign new connection to edge array, increase # of connections
//            if(fromVertex == toVertex) //if connection refers to self
//            {
//                edge[fromVertex][toVertex] = 1;
//                vertex[fromVertex].addConnection();
//                return true;
//            }
//            else
//            {
            //Establish edge connection for both nodes to each other
                edge[fromVertex][toVertex] = 1;
                edge[toVertex][fromVertex] = 1;

                //increase number of connections for each node
                vertex[fromVertex].addConnection();
                vertex[toVertex].addConnection();
                
                //increase total # of connections by 1
                totalConnections++;
                
                //determine random edge weight and save.
                //select random value between 1 - 20
                weight = number.nextInt(10);
                
                //if weight is 0, reassign value
                while(weight == 0)
                {
                    weight = number.nextInt(50);
                }
                
                edgeWeight[fromVertex][toVertex] = weight;
                edgeWeight[toVertex][fromVertex] = weight;

                return true;    
//            }
            
        }
    }//end of insertEdge method
    
    
    public void establishConnections()
    {
        Random number = new Random(); //Initializes random generator
        int toVertex;
        
        System.out.println("Establishing connections between nodes now.");
        
        for(int i = 0; i < vertex.length; i++)
        {
            //selects random vertex in graph to connect to
            toVertex = number.nextInt(max);
            
            //Vertex should NOT connect to ITSELF, select another vertex
            if(toVertex == i)
            {
                toVertex = number.nextInt(max);
            }
            //if random number selected is equal to current vertex selected
            //retry. Connection already exists.
            if(edge[i][toVertex] == 1)
            {
               toVertex = number.nextInt(max);
            }
            else
            {
                //send information to insertEdge method to add connection
               insertEdge(i, toVertex); 
            }
        }
        
        System.out.println("Connections complete.");
    }//end of establishedConnections method
    

    
    
    
    
    
    
    
    //Search methods
    
    /*Depth-First traversal method. Performs an EXHAUSTIVE search through all
    * of the vertices in the graph and prints them.
    */
    public void DFT()
    {

        //initialize a new stack object using predefined java Stack class
        Stack<Integer> stack = new Stack();
        
        //reset all vertices' visit variable to false
        for(int i = 0; i < numberOfVertices; i++)
        {
            if(vertex[i] != null)
            {
                vertex[i].setVisit(false);
            }
        }
        
        stack.push(vertex[0].getValue()); //visit the first vertex
        vertex[0].setVisit(true);
        
        int v; //will hold the value popped from stack
        
        //visit all of the descendants until you find the search value (or not)
        while(!stack.empty())
        {
            v = stack.pop();
            
            //if value of v is greater than number of nodes in graph
            //its so value of vertex[0] can be used without messing up program
            if(v > numberOfVertices)
            {
                for(int i = 0; i < numberOfVertices; i++)
                {
                    if(vertex[i].getValue() == v)
                    {
                        v = i; //reset value of v
                    }
                    else
                    {
                        //continue
                    }
                }
            }
            
            
            //vertex[v].visit(); //visit the vertex
            
            for(int row = 0; row < numberOfVertices; row++)
            {
                for(int column = 0; column < numberOfVertices; column++)
                {
                    //if connection exists and current vertex has not been visited
                    if(edge[row][column] == 1 && !vertex[column].getVisit())
                    {
                       stack.push(column);
                       vertex[column].setVisit(true);   
                    }//end if
                }//end inner For loop
            }//end of outer For loop
        }//end while
        
    }//End DFT exhaustive method
    
    
    /*Depth-First traversal method. Modified to start at first vertex in graph
    * and search until either the "search" value is encountered or all values are
    * used in the graph. Returns success/failure to user. EXHAUSTIVE if nothing is
    * found!
    */
    public void DFTSearch(int firstVertex, int search)
    {

        //initialize a new stack object using predefined java Stack class
        Stack<Integer> stack = new Stack();
        int pathLength = 0;
        int path = 0;
        
        //reset all vertices' visit variable to false
        for(int i = 0; i < numberOfVertices; i++)
        {
            if(vertex[i] != null)
            {
                vertex[i].setVisit(false);
            }
        }
        
        stack.push(firstVertex); //visit the first vertex
        vertex[firstVertex].setVisit(true);
        
        int v; //will hold the value popped from stack
        int vertexSearch = 1; //holds number of vertices searched
        boolean found = false; //will be true when "search" value is found
        //visit all of the descendants until you find the search value (or not)
        while(!stack.empty() || found == false)
        {
            v = stack.pop();
            //vertex[v].visit(); //visit the vertex
            
            for(int row = 0; row < numberOfVertices; row++)
            {
                for(int column = 0; column < numberOfVertices; column++)
                {
                    //if connection exists and current vertex has not been visited
                    if(edge[row][column] == 1 && !vertex[column].getVisit())
                    {
                        if(found == false)
                        {
                          stack.push(column);
                          vertex[column].setVisit(true);  
                          
                          pathLength = pathLength + edgeWeight[row][column];
                          
                          vertexSearch++; //add to number of vertices searched
                          
                          //if this vertex matches the search value, set "found" to true
                          if(vertex[column].getValue() == search)
                          {
                              found = true;
                              path = pathLength;
                          }
                        }
                        else
                        {
                            //Do nothing if value was found!
                            //System.out.println("Value was found!");
                        }
                        
                    }//end if
                }//end inner For loop
            }//end of outer For loop

        }//end while
        
        if(found == true)
        {
            System.out.println("Value " + search + " was found!"
                    + "\nLength of path taken to find value: " + path);
        }
        else
        {
            System.out.println("Value " + search + " was not found.");
        }
        
        System.out.println("Number of vertices examined to find value: " 
                    + vertexSearch);
    }//End DFT search method
    
    
    /*Breadth-First traversal method. Performs an EXHAUSTIVE search through all
    * of the vertices in the graph and prints them.
    */
    public void BFT(int s)
    {
       
        //initialize a new queue object using predefined java Stack class
        LinkedList<Integer> q = new LinkedList<>();

        //reset all vertices' visit variable to false
        for(int i = 0; i < numberOfVertices; i++)
        {
            if(vertex[i] != null)
            {
                vertex[i].setVisit(false);
            }
        }
        
        q.add(vertex[s].getValue()); //visit the first vertex
        vertex[s].setVisit(true);
        
        //visit all of the descendants until you find the search value (or not)
        while(!q.isEmpty())
        {
            //remove vertex from queue and print it
            s = q.poll();
            System.out.println(s);        
            
            for(int row = 0; row < numberOfVertices; row++)
            {
                for(int column = 0; column < numberOfVertices; column++)
                {
                    //if connection exists and current vertex has not been visited
                    if(edge[row][column] == 1 && !vertex[column].getVisit())
                    {
                       s = vertex[column].getValue();
                       q.add(s);
                       vertex[column].setVisit(true);   
                    }//end if
                }//end inner For loop
            }//end of outer For loop
        }//end while
        
    }//End BFT exhaustive method
    
    
    /*Breadth-First traversal method. Modified to start at first vertex in graph
    * and search until either the "search" value is encountered or all values are
    * used in the graph. Returns success/failure to user. EXHAUSTIVE if nothing is
    * found! v = vertex, s = search
    */
    public void BFTSearch(int v, int s)
    {
        //initialize a new stack object using predefined java Stack class
        LinkedList<Integer> q = new LinkedList<>();
        int pathLength = 0; //logs length of path taken to find desired node
        int path = 0; //final path length taken to find desired node
        
        //reset all vertices' visit variable to false
        for(int i = 0; i < numberOfVertices; i++)
        {
            if(vertex[i] != null)
            {
                vertex[i].setVisit(false);
            }
        }
        
        
        q.add(vertex[v].getValue()); //visit the first vertex
        vertex[v].setVisit(true);
        
        int vertexSearch = 1; //holds number of vertices searched
        boolean found = false; //will be true when "search" value is found
        //visit all of the descendants until you find the search value (or not)
        while(!q.isEmpty() || found == false)
        {
            //remove vertex from queue and print it
            v = q.poll();
            //System.out.println(v);
            
            for(int row = 0; row < numberOfVertices; row++)
            {
                for(int column = 0; column < numberOfVertices; column++)
                {
                    //if connection exists and current vertex has not been visited
                    if(edge[row][column] == 1 && !vertex[column].getVisit())
                    {
                        if(found == false)
                        {
                            v = vertex[column].getValue();
                            q.add(v); //add value to queue
                            vertex[column].setVisit(true);  
                            
                            pathLength = pathLength + edgeWeight[row][column];
                          
                            vertexSearch++; //add to number of vertices searched
                          
                          //if this vertex matches the search value, set "found" to true
                          if(vertex[column].getValue() == s)
                          {
                              found = true;
                              path = pathLength;
                          }
                        }
                        else
                        {
                            //Do nothing if value was found!
                            //System.out.println("Value was found!");
                        }
                        
                    }//end if
                }//end inner For loop
            }//end of outer For loop

        }//end while
        
        if(found == true)
        {
            System.out.println("Value " + s + " was found!"
                    + "\nLength of path to find value: " + path);
        }
        else
        {
            System.out.println("Value " + s + " was not found.");
        }
        
        System.out.println("Number of vertices examined to find value: " 
                    + vertexSearch);
    }//End BFT search method
    
    
    /* Find the shortest distance between chosen node and ALL other nodes in the
        graph.
    */
    public void DijkstraSearch(int start)
    {
        //reset all nodes to unvisited
        for(int i = 0; i < numberOfVertices; i++)
        {
            vertex[i].setVisit(false);
        }
        
        //array will hold neighboring nodes for current vertex
        int[] neighbors = new int [numberOfVertices];
        for(int i = 0; i < neighbors.length; i++)
        {
            neighbors[i] = 9999; //impossible value
        }
        
        //array will hold the min distance between each vertex & chosen vertex.
        minDistance = new int [numberOfVertices][numberOfVertices];
        
        //value counting number of vertices completed in algorithm
        int visited = 0;
        int count = 0; //for counting number of neighbors in array
        
        //will hold array index of current vertex being examined. Begins with
        //start value.
        int currentVertex = start;
        int nextVertex = currentVertex; //holds upcoming next vertex to check
        
        
        //add all distances from start node to minDistance array to begin
        for(int i = 0, k = 0; i < numberOfVertices; i++)
        {
            if(edge[currentVertex][i] == 1)
            {
                //if a connection exists between start vertex and other vertex
                //then transfer weight value of that connection to min list
                System.out.println("Connection exists. Transferring...");
                minDistance[currentVertex][i] = edgeWeight[currentVertex][i]; 
                
                neighbors[count] = i; //add to neighbors array
                count++;
                k++;
                
                //System.out.println("The neighbor vertex of current vertex[" + currentVertex + "] is: " + i);
            }
            else
            {
                //otherwise set it to an impossible value.
                //System.out.println("Connection does not exist.");
                minDistance[currentVertex][i] = 9999999;
            }
//            System.out.println("Weight of path connecting Vertex " + currentVertex + 
//                    " to Vertex " + i + ": " + minDistance[currentVertex][i]);
        }
        //Works to this point
        
        
        
        System.out.println("\nCurrent vertex has been visited: " + vertex[currentVertex].getVisit());
        
        
        while(visited < numberOfVertices)
        {
            
        
        //determine which neighboring vertex to visit next, and what other nodes to check.
        System.out.println("\nChecking which neighbor to visit next...");
        
        for(int i = 0, k = 0, L = 1; i < count; i++)
        {
            //make sure to properly transfer value from neighbors to k so we are
            //checking the correct vertex!
            k = neighbors[i];
            L = neighbors[i + 1];
//            System.out.println("Vertex of k is: " + k);
//            System.out.println("Vertex of L is: " + L);
            
            //if there is ONLY ONE other vertex connected to current vertex
            //then go straight to that. WORKS
            if(count == 1 && vertex[k].getVisit() == false)
            {
//                System.out.println("Skipping to only connected vertex...");
                nextVertex = k;
//                System.out.println("Now checking vertex " + nextVertex);
            }
            
            //if more than 1 connected vertex
            else if(count > 1)
            {
                //if vertex has already been visited.
                if(vertex[k].getVisit() == true)
                {
//                    System.out.println("Vertex " + k + " has already been visited.");
                }
                
                //if vertex has not been visited yet
                else if(vertex[k].getVisit() == false)
                {
                    //if L is 0, then likely at end of neighbors array
                    //no other neighbor options to compare WORKS
                    if(L == 9999)
                    {
//                        System.out.println("NO other neighboring vertices to compare.");
                    }
                    
                    //if the weight of path i is less than path k, then save that as next vertex
                    else if(edgeWeight[currentVertex][k] < edgeWeight[currentVertex][L])
                    {
//                        System.out.println("Weight of K(" + edgeWeight[currentVertex][k] 
//                                + ") is less than L (" 
//                                + edgeWeight[currentVertex][L] + ")");

                        nextVertex = k;

//                        System.out.println("Value of next vertex to examine is: " + nextVertex);
                    }
                    else if(edgeWeight[currentVertex][L] < edgeWeight[currentVertex][k])
                    {
//                        System.out.println("Weight of L(" + edgeWeight[currentVertex][L] 
//                                +") is less than K("  
//                                + edgeWeight[currentVertex][k] + ")");
                        
                        nextVertex = L;
                        
//                        System.out.println("Value of next vertex to examine is: " + nextVertex);
                    }
                }
                //last check to make sure we have shortest path selected
                else if(edgeWeight[currentVertex][k] < edgeWeight[currentVertex][nextVertex])
                        {
                            nextVertex = k;
                        }
                
            }
            
            
//            System.out.println("\nMoving on to next option.");
        }
        
            count = 0;
            
            System.out.println("\nPrevious vertex checked: " + currentVertex);
            
            vertex[currentVertex].setVisit(true); //done with first vertex.
//            System.out.println("Current vertex has been visited: " + vertex[currentVertex].getVisit());
            visited++;
            
            currentVertex = nextVertex;
            System.out.println("Current vertex is: " + currentVertex 
                    + " and next vertex is: " + nextVertex);
            
//            System.out.println("\nSearching for neighbors of next vertex...");
            
            for(int i = 0; i < neighbors.length; i++)
            {
                
                if(edge[currentVertex][i] == 1 && vertex[i].getVisit() == false)
                {
                    //if a connection exists between start vertex and other vertex
                    //then transfer weight value of that connection to min list
//                    System.out.println("Connection exists. Adding to neighbors...");
                    //minDistance[currentVertex][i] = edgeWeight[currentVertex][i]; 

                    neighbors[count] = i; //add to neighbors array
                    count++;

//                    System.out.println("The neighbor vertex of current vertex[" + currentVertex + "] is: " + i);
                }
                else
                {
                    //otherwise set it to an impossible value.
                    //System.out.println("Connection does not exist.");
                    neighbors[i] = 9999; //impossible value
                }
                
//                System.out.println("Weight of path connecting Vertex " + currentVertex + 
//                        " to Vertex " + i + ": " + minDistance[currentVertex][i]);
        
            }
            
            
            //temp
            System.out.println("\nNot implemented yet!");
            //visited = numberOfVertices;
        
        }
//        //pass information to recursive method
//        DijkstraRecursive(currentVertex, minDistance);
//        
        
        
    }
    
    
    
    
//    //Recursive method that analyzes neighbors of current node
//    //nodes marked "neighbor" have been checked for the current node
//    //nodes marked "visited" have had all neighboring nodes checked for that node
//    private void DijkstraRecursive(int currentVertex, int[][] minDistance)
//        {
//            
//            //array that will hold indexes to vertices neighboring current node
//            int [] option = new int[numberOfVertices];
//            int next = 0; //will hold value of next vertex to check
//            
//            //if visited is greater than numberOfVertices, then quit
//            if(visited > numberOfVertices)
//                {
//                    return;
//                }
//            else
//            {
//
//            int options = 0; //holds option array length
//            
//            //look for connections to current vertex / node
//            for(int i = 0, j = 0; i < numberOfVertices; i++)
//            {
//                //if a connection between current vertex & other vertex exist
//                //then copy that index value to option array
//                //copy edge weight to minDistance array 
//                if(edge[currentVertex][i] == 1)
//                {
//                    System.out.println("Connection found! Copying edge weight...");
//                    option[j] = i;
//                    minDistance[currentVertex][i] = edgeWeight[currentVertex][i];
//                    options++;
//                    j++;
//                }
//                else
//                {
//                    //System.out.println("No connection found, continuing...");
//                }
//            }
//            
//            //while current node is not completely checked for neighbors
//            while(vertex[currentVertex].getVisit() == false)
//            {
//                //if there is more than 1 option of neighbors
//                if(options > 1)
//                {
//                    for(int i = 0; i < options; i++)
//                    {
//                        for(int j = 0; j < options; j++)
//                        {
//                            //if option[i] is less than option[j], set i to next vertex
//                            if(edgeWeight[currentVertex][option[i]] 
//                                    < edgeWeight[currentVertex][option[j]])
//                            {
//                                next = option[i];
//                            }
//                            //if option[j] is less than option[i], set j to next vertex
//                            else if(edgeWeight[currentVertex][option[j]] 
//                                    < edgeWeight[currentVertex][option[i]])
//                            {
//                                next = option[j];
//                            }
//                        }
//                    }
//                    //transfer value of next to currentVertex & visit currentVertex
//                    vertex[currentVertex].setVisit(true);
//                    currentVertex = next;
//                    visited++;
//                }
//                //else take that value as next vertex to check & set visit to true
//                else
//                {
//                    vertex[currentVertex].setVisit(true);
//                    currentVertex = option[0];
//                    visited++;
//                } 
//            }//end of while statement, vertex has been visited
//            } //end of else statement
//            
//            DijkstraRecursive(currentVertex, minDistance);
//     }//end of recursive search Dijkstra
    
    
    
    
    
    
    
    
    
    //print methods
    public void printGraphVertices()
    {
        for(int i = 0; i < numberOfVertices; i++)
        {
            vertex[i].print(i);
        }
    }//end of printGraphVertices method
    
    
    public void printConnections()
    {
        for(int i = 0; i < edge.length; i++)
        {
            System.out.print("Vertex " + (i + 1) + ": ");
            
//            for(int j = 0; j < edge.length; j++)
//            {
//               System.out.print(" " + edge[i][j] + " "); 
//            }
            //print number of connections per vertex in graph
            System.out.print(" # of Connections: " + vertex[i].getConnections());
            System.out.println();
        }
    }//end of printConnections method
    
    
    public int getVertexValue(int number)
    {
        return vertex[number].getValue();
    }
    
    
    public void printWeight()
    {
        
        for(int i = 0; i < numberOfVertices; i++)
        {
            for(int j = 0; j < numberOfVertices; j++)
            {
                int edgeLength = edgeWeight[i][j];
                
                //connection exists
                if(edgeLength != 0)
                {
                    System.out.print("Vertex " + (i + 1) + " to Vertex " + (j + 1) + " Weight: ");
                    System.out.print("" + edgeLength + "\n");
                }
                else
                {
                    //just continue
                }
                
            }
        }
        
    }
    
    
    public void getWeight(int fromVertex, int toVertex)
    {
        if(edge[fromVertex][toVertex] == 0)
        {
            System.out.println("There is not path directly connecting " 
                    + (fromVertex + 1) +
                    " to " + (toVertex + 1) + "!");
        }
        else
        {
            System.out.println("The weight of the connection between Vertex " + 
                    (fromVertex + 1) + " and Vertex " + (toVertex + 1) + " is "
                    + edgeWeight[fromVertex][toVertex]);
        }
    }
    
    public void getTotalConnections()
    {
        System.out.print(totalConnections);
    }
    
}//End of Class Node
