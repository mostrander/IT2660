/*
 * To hold the values of each individual node
 */
package it2660_randomgraph;

import java.util.Random;

/**
 *
 * @author Megan Ostrander
 */
public class Listing {
    
    private int value; //Holds random number value for node
    private int connections; //Holds number of connections Node has
    private int allowedConnections; //Holds number of connections Node allowed to have
    
    private boolean visited = false; //auto set to not visited
    private boolean neighbor = false; //auto set to not neighbored
    
    Random number = new Random(); //Initializes random generator
    
    //Constructor for Listing class
    public Listing()
    {
        value = number.nextInt(300001); //Value between 0 - 300,000
        connections = 0;
        allowedConnections = 0; //temp value, will be replaced below
        
        while(allowedConnections == 0) //retry if value is zero
        {
           allowedConnections = number.nextInt(6); //value between 1 - 5 
        }

    }
    
    //Constructor for Listing class
    public Listing(int Value)
    {
        value = Value; //Value between 0 - 300,000
        connections = 0;
        allowedConnections = 0; //temp value, will be replaced below

        while(allowedConnections == 0) //retry if value is zero
        {
           allowedConnections = number.nextInt(6); //value between 1 - 5 
        }
    }
    
    //Constructor for Listing class
    public Listing(int Value, int Connections, int Allowed)
    {
        value = Value; //Value between 0 - 300,000
        connections = Connections;
        allowedConnections = Allowed; //temp value, will be replaced below
    }
    
    //Print method for array values
    //Print method for individual nodes
    public void print(int i)
    {
        System.out.println("Value of vertex " + (i + 1) + " is: " + getValue() + " ");
    }
    
    public void addConnection()
    {
        //increase number of connections made for listing
        connections++;
    }
    
    
    //Retrieve methods for Node class
    public int getValue()
    {
        return this.value;
    }

    //returns number of connections for Listing
    public int getConnections()
    {
        return connections;
    }
    
    //returns number of connections allowed for Listing
    public int getAllowed()
    {
        return allowedConnections;
    }
    
    
    //returns whether or not vertex has been visited as a neighbor
    public boolean getNeighbor()
    {
        return neighbor;           
    }
    
    //sets value of visited variable for vertex
    public void setNeighbor(boolean value)
    {
        neighbor = value;
    }
    
    //returns whether or not vertex has been visited
    public boolean getVisit()
    {
        return visited;           
    }
    
    //sets value of visited variable for vertex
    public void setVisit(boolean value)
    {
        visited = value;
    }
    
    //prints the vertex being visited
    public void visit()
    {
        System.out.println(this.value);
    }
    
    
    
    //method for creating copy of calling object
    public Listing deepCopy()
    {
        //System.out.println("Copying ..."); //test
        Listing clone = new Listing(value, connections, allowedConnections);
        return clone;
    }

    
}
