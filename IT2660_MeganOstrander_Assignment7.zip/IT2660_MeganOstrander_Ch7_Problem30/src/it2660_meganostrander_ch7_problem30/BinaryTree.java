/*
 * To create a binary tree of student listings that adds, updates, & deletes 
 *      listing from the binary tree. I was able to make the insert methods
 *      function, but I do not provide a resorting option in this project.
 */
package it2660_meganostrander_ch7_problem30;

/**
 *
 * @author Megan Ostrander
 */

import java.util.Arrays;

public class BinaryTree {
    
    //Create root of binary tree
    Node root;
    
    //constructors
    BinaryTree()
    {
        root = null;
        //Note: left & right children already set to null
    }
    
    //WORKS
    BinaryTree(Listing student)
    {
        //need to create as a new node to function right
        root = new Node(student);
    }
    
    //WORKS
    BinaryTree(Listing [] students)
    {
        //set root as first value in array
        root = new Node(students[0]);

        //pass array to insertNode method to add values to tree
        insertNodes(root, students, 0);
        
    }
    
    //WORKS
    BinaryTree(Listing [] students, int division)
    {
        //set root as first value in array
        root = new Node(students[0]);

        //pass array to divide method to add values to new, smaller array
        //before adding to tree
        divide(students, division, 0);
        
    }

    
    //Division method to divide array up into smaller 10 element groups
    //then passed to insert array method. WORKS
    //RECURSIVE!
    private void divide(Listing [] list, int division, int start)
    {
        //create new array to hold smaller group of elements
        Listing [] group = new Listing[10];
        
        for(int j = 0; j < 10; j++)
        {
            if(start >= list.length)
            {
                j = 10;
            }
            else
            {
               //transfer values from original list to new group 
                group[j] = list[start];
                start++; 
            }
            
        }
        
        //pass new array to insertNodes array method
        insertNodes(root, group, 0);
        
        //then iterate back through this method if start < original list length
        if(start >= list.length)
        {
            System.out.println("End of List division.\nNumber of divisions: "
                        + division);
            return;
        }
        else
        {
            divide(list, division, start);
        }
        
        
    }
    
    
    
    //insert method
    //NEED TO WORK ON
    public void insertNode(Node node, Listing student)
    {
        if(root.data == null)
        {
            System.out.println("Root is empty!");
            return;
        }

        //if value is empty, end recursion
        else if(student == null)
        {
            return;
        }
        
        System.out.println("Adding + " + student.getKey() + " to the list...");
        
        //if current value is greater than node, move to left branch
        if(student.getKey().compareToIgnoreCase(node.getData()) < 0)
        {
            //if left branch for current node is not null, move down tree 
            //and run through method again with new node
            if(node.left != null)
            {
                //System.out.println("The left child of this node is full. "
                        //+ "Moving down the chain...");
                insertNode(node.left, student);
            }
            //else, create new node and add to left child of current node
            else
            {
                //System.out.println("Inserting new listing as left child of node: "
                        //+ "" + node.getData());
                node.left = new Node(student);
            }
        }
        //else, move to the right branch
        else if (student.getKey().compareToIgnoreCase(node.getData()) > 0)
        {
            //if right branch for current node is not null, move down tree 
            //and run through method again with new node
            if(node.right != null)
            {
                //System.out.println("The right child of this node is full. "
                        //+ "Moving down the chain...");
                insertNode(node.right, student);
            }
            //else, create new node and add to right child of current node
            else
            {
                //System.out.println("Inserting new listing as right child of node: "
                        //+ "" + node.getData());
                node.right = new Node(student);
            }
        }
    }
    

    //inserts an array of unsorted values into a tree, resets to root every iteration
    //so it should search for location to insert next listing. WORKS!
    //RECURSIVE!
    private void insertNodes(Node node, Listing[] students, int current)
    {
        if(root.data == null)
        {
            System.out.println("Root is empty!");
            return;
        }

        //if value is empty, end recursion
        else if(students[current] == null)
        {
            return;
        }
        
        //if value is the root, skip and continue recursion
        else if(students[current].getKey().compareToIgnoreCase(root.getData()) == 0)
        {
            System.out.println(students[current].getKey() + 
                    " is the root of this tree. Skipping...");
            current++;
            insertNodes(root, students, current);
        }
        
        
        //if current value is greater than node, move to left branch
        else if(students[current].getKey().compareToIgnoreCase(node.getData()) < 0)
        {
            //if left branch for current node is not null, move down tree 
            //and run through method again with new node
            if(node.left != null)
            {
                //System.out.println("The left child of this node is full. "
                        //+ "Moving down the chain...");
                insertNodes(node.left, students, current);
            }
            //else, create new node and add to left child of current node
            else
            {
                //System.out.println("Inserting new listing as left child of node: "
                        //+ "" + node.getData());
                node.left = new Node(students[current]);
            }
        }
        //else, move to the right branch
        else if (students[current].getKey().compareToIgnoreCase(node.getData()) > 0)
        {
            //if right branch for current node is not null, move down tree 
            //and run through method again with new node
            if(node.right != null)
            {
                //System.out.println("The right child of this node is full. "
                        //+ "Moving down the chain...");
                insertNodes(node.right, students, current);
            }
            //else, create new node and add to right child of current node
            else
            {
                //System.out.println("Inserting new listing as right child of node: "
                        //+ "" + node.getData());
                node.right = new Node(students[current]);
            }
        }
        
        //check that current is still less than length of array
        //increase "current" to move to next element in array students
        current++;
        
        if(current >= students.length)
        {
            //end recursive run.
            return;
        }
        else
        {
            //then run through method again.
            //System.out.println("Running through method again.");
            
            insertNodes(root, students, current);
        }
        

        //System.out.println("Tree creation complete.");
    }
     
    
    
    //recursive method
    //works currently.
    public void searchTree(Node node, String student)
    {
        //if root is null, then tree does not exist!
        if(root == null)
        {
            System.out.println("Tree is empty!");
            return;
        }
        
        //if current node or string passed does not hold a value, skip it.
        if(node == null || student == null)
        {
            return;
        }

        if(node.data.getKey().equalsIgnoreCase(student))
        {
            System.out.println("Value found!");
            System. out.println("Node: " + node.getData());
            return;
        }
        else
        {
            System.out.println("Value not found.");
        }
        
        //run through the left branches/subtree first
        searchTree(node.left, student);
        
        //then run through the right/subtree branches
        searchTree(node.right, student);
    }
    
    
    //Recursive method!
    //desired = node to change; student = new data to add; node = initially root
    //GOT IT WORKING!!
    public void updateTree(Node node, String value, Listing student)
    {
        if(root == null)
        {
            System.out.println("Tree does not exist.");
            return;
        }
        
        if(node == null)
        {
            return;
        }
        

        else if(node.data.getKey().equalsIgnoreCase(value))    
        {
            //change the data in the tree to reflect new value
            System.out.println("Updating listing in the tree...");
            node.data = student;
            return;
        }

        else
        {
            System.out.println("Value not found.");
        }
        
        
        //check left branches of tree
        updateTree(node.left, value, student);
        
        //check right branches of tree
        updateTree(node.right, value, student);

    }
    
    //calls delete method
    public void delete(String value)
    {
        deleteNode(root, value);
    }

    //currently working
    Node deleteNode(Node node, String value)
    {

        if(node == null)
        {
            return node;
        }
        
        if(node.data.getKey().compareTo(value) > 0)
        {
            //check left branches of tree
            System.out.println("Checking left branch...");
            deleteNode(node.left, value);
        }
        
        else if(node.data.getKey().compareTo(value) < 0)
        {
            //check right branches of tree
            System.out.println("Checking right branch...");
            deleteNode(node.right, value);
        }
        
        else if (node.data.getKey().equalsIgnoreCase(value))   
        {
            //change the data in the tree to reflect new value
            System.out.println("Deleting listing in the tree...");

            if(node.left == null)
            {
                System.out.println("Replacing with right child.");
                return node.right;
            }
            else if(node.right == null)
            {
                System.out.println("Replacing with left child.");
                return node.left;
            }
            
            //for nodes with both children values
            //check right branch for next smallest value, delete that value after
            //placing in new place
            node.data = minValue(node.right);
            
            node.right = deleteNode(node.right, node.data.getKey());

        }

        else
        {
            System.out.println("Value does not exist in tree.");
        }

        
        return node;
    }
    

    
    //RECURSIVE PRINT METHOD (preorder style; prints root, followed by left & 
    //right branches
    //WORKS
    public void printTree(Node node)
    {
        if(root == null)
        {
            System.out.println("Cannot print empty tree.");
            return;
        }

        else if (node != null)
        {
            System.out.println(node.data.getKey());
            
            //run through the left branches/subtree first
            //System.out.println("Left branch: ");
            printTree(node.left);

            //then run through the right/subtree branches
            //System.out.println("Right branch: ");
            printTree(node.right);
        }
        
        
        
        
    }
    
    
    //recursive print method for left branch only (pass root.left initially)
    public void printLeftBranch(Node node)
    {
        //Pass root.left to this method to print ONLY the left half of tree
        if(node == null)
        {
            return;
        }
        
        System.out.println(node.data.getKey() + " ");
        
        //run through the left branches/subtree first
        printLeftBranch(node.left);
        
        //then run through the right/subtree branches
        printLeftBranch(node.right);
        
    }
    
    //Recursive print method for right branch only (pass root.right initially)
    public void printRightBranch(Node node)
    {
        //Pass root.right to this method to print ONLY the right half of tree
        if(node == null)
        {
            return;
        }
        
        System.out.println(node.data.getKey() + " ");
        
        //run through the left branches/subtree first
        printRightBranch(node.left);
        
        //then run through the right/subtree branches
        printRightBranch(node.right);
        
    }
    
    
    
    
    
    public String showRoot(Node root)
    {
        return root.data.getKey();
    }
    
    
    
    //wrappers for above methods
    public void printTree()
    {
        printTree(root);
    }
    
    public void printLeftBranch()
    {
        printLeftBranch(root.left);
    }
    
    public void printRightBranch()
    {
        printRightBranch(root.right);
    }

    private Listing minValue(Node node) 
        //used to find next smallest value in right subtree
        {
            Listing minValue = node.data;

            while(node.left != null)
            {
                minValue = node.left.data;
                node = node.left;
            }

            return minValue;
        }


}
