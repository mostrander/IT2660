/*
 * To create a binary tree of student listings that adds, updates, & deletes 
 *      listing from the binary tree. I was able to make the insert methods
 *      function, but I do not provide a resorting option in this project.
 */
package it2660_meganostrander_ch7_problem30;

import java.util.Scanner;

/**
 *
 * @author Megan Ostrander
 */
public class IT2660_MeganOstrander_Ch7_Problem30 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // retry for binary tree

//        //test of creating a basic binary tree with listing objects
//        BinaryTree tree = new BinaryTree(); //empty
//        
//        Listing student1 = new Listing("Jill");
//        Listing student2 = new Listing("William");
//        Listing student3 = new Listing("Anna");
//        Listing student4 = new Listing("Anne");
//        Listing student5 = new Listing("Zatch");
//        Listing student9 = new Listing("Sam");
//        
//        tree.root = new Node(student1);
//        tree.root.left = new Node(student3);
//        tree.root.left.right = new Node(student4);
//        tree.root.right = new Node(student2);
//        tree.root.right.right = new Node(student5);
//        tree.root.left.left = new Node(student9);
//        
//        //test basic printTree method (uses INORDER style)
//        System.out.println("Testing the printTree method. Should be root first, "
//                + "followed by left & right branches.");
//        System.out.println("Root is: " + tree.showRoot(tree.root) + "\n");
//        
//        tree.printTree(tree.root);
//        
//        //works up to this point!
//        System.out.println("\nTest of wrapper for printTree method.");
//        tree.printTree();
//        
//        //test of the LeftBranch & RightBranch print methods & wrappers
//        System.out.println("\nTesting printLeftBranch method...");
//        tree.printLeftBranch(tree.root.left);
//        
//        System.out.println("\nTesting printRightBranch method...");
//        tree.printRightBranch(tree.root.right);
//        
//        System.out.println("\nTesting wrapper classes for previous print methods.");
//        tree.printLeftBranch(); 
//        System.out.println(" ");
//        tree.printRightBranch();
//        
//        //works up to this point!
//
//        
//        //test for searchTree method
//        System.out.println("\nSearching for 'Abby': ");
//        tree.searchTree(tree.root, "Abby");
//        
//        System.out.println("\nSearching for root this time: ");
//        tree.searchTree(tree.root, tree.root.getData());
//        
//        System.out.println("\nWho is student 3? ");
//        tree.searchTree(tree.root, "William");
//        
//        System.out.println("\nWho is student 5? ");
//        tree.searchTree(tree.root, student5.getKey());
//        
//        //additional testing for searchTree method
//        Scanner keyboard = new Scanner(System.in);
//        keyboard.useDelimiter("[/\r\n]");
//        
//        System.out.println("\nPlease enter a name for a new student: ");
//        String name = keyboard.next();
//        
//        System.out.println("\nDo we have a student named " + name + "? ");
//        tree.searchTree(tree.root, name);
//        
//        
//        //testing for delete method
//        System.out.println("\nTesting the delete method for 'Anna' ");
//        System.out.println("\nPrinting current tree...");
//        tree.printTree();
//
//        tree.delete("Anna");
//        
//        System.out.println("\nPrinting tree after delete.");
//        tree.printTree();
//        
//        
//        //testing for updateTree method
//        //create a "desired" listing object to hold value to search for
//        //Try to change root first
//        
//        System.out.println("\nTesting the updateTree method 1...");
//        System.out.println("Printing original tree: \nRoot: " + tree.showRoot(tree.root));
//        tree.printTree();
//        Listing change = new Listing("FUCK U");
//        
//        //pass information to update tree values, pass root to begin there,
//        //pass string as value to search for, & "change" for new value
//        tree.updateTree(tree.root, "Jill" , change);
//        
//        System.out.println("Printing updated tree...");
//        System.out.println("Root is: " + tree.showRoot(tree.root));
//        tree.printTree();
//        
//        //test 2 for update
//        //won't update tree root second time...
//        System.out.println("\nTesting the updateTree method 2...");
//        System.out.println("Printing original tree: \nRoot: " + tree.showRoot(tree.root));
//        tree.printTree();
//        Listing change2 = new Listing("siiigh");
//        tree.updateTree(tree.root, "annE" , change2);
//        
//        System.out.println("Printing updated tree...");
//        System.out.println("Root is: " + tree.showRoot(tree.root));
//        tree.printTree();
        
        //testing creating a binary tree with array of listings
        //create an array of student listings and use that to create new tree
        
        Listing [] list = new Listing[12];
        Listing student;
        
        for(int i = 0; i < list.length; i++)
        {
            //create new listing
            student = new Listing();
            student.input();
            
            //place new listing in array
            list[i] = student;
        }
        
        //pass array to BinaryTree constructor
        System.out.println("Creating the tree...");
        
        BinaryTree studentTree;
        
        if(list.length > 10)
        {
            int length = list.length;
            
            //number of times divide method will need to recurse to make smaller
            //arrays of size 10.
            int division = length/10;
            
            studentTree = new BinaryTree(list, division);
        }
        else
        {
            studentTree = new BinaryTree(list);
        }
        
        
        
        //Now see if tree prints as hoped.
        System.out.println("\nPrinting studentTree now... \n");
        studentTree.printTree();
        
        
        //test of insertNode method
        Listing ruby = new Listing("Ruby");
        
        studentTree.insertNode(studentTree.root, ruby);
        
        //reprint the binary tree 
        studentTree.printTree();
        
        
        
    } //end of main class
    
    
    
    //merge split methods copied from recursive assignment,
    //modified to sort string names instead!
    public static Listing[] TopDownSplitMerge(Listing list[])             
    {
        //If list is empty; no need to do anything
        if (list.length <= 1) {
            return list;
        }
         
        //System.out.println("List before dividing...");
        //System.out.println(Arrays.toString(list) +"\n");
        
        //Split the array in half in two parts
        Listing[] first = new Listing[list.length / 2];
        Listing[] second = new Listing[list.length - first.length];
        

        // Uses System.arraycopy to copy the array.
        System.arraycopy(list, 0, first, 0, first.length);
        System.arraycopy(list, first.length, second, 0, second.length);
         
        //Sort each half recursively
        TopDownSplitMerge(first);
        TopDownSplitMerge(second);
         
        //Merge both halves together, overwriting to original array
        TopDownMerge(first, second, list);
        return list;
    }
     
    private static void TopDownMerge(Listing first[], Listing second[], Listing result[])             
    {
        //Index Position in first array - starting with first element
        int iFirst = 0;
         
        //Index Position in second array - starting with first element
        int iSecond = 0;
         
        //Index Position in merged array - starting with first position
        int iMerged = 0;
         
        //Compare elements at iFirst and iSecond, 
        //and move smaller element at iMerged
        while (iFirst < first.length && iSecond < second.length) 
        {
            //have to compare the key values specifically or it won't work!
            if (first[iFirst].getKey().compareTo(second[iSecond].getKey()) < 0) 
            {
                result[iMerged] = first[iFirst];
                iFirst++;
            } 
            else
            {
                result[iMerged] = second[iSecond];
                iSecond++;
            }
            iMerged++;
            //System.out.println("Printing current result list...");
            //System.out.println(Arrays.toString(result) +"\n");
        }
        //copy remaining elements from both halves - each half will have already sorted elements
        System.arraycopy(first, iFirst, result, iMerged, first.length - iFirst);
        System.arraycopy(second, iSecond, result, iMerged, second.length - iSecond);
    }
    
} //end of program
