/*
 * To create the node relationship for the binary tree ONLY
 */
package it2660_meganostrander_ch7_problem31;

import java.util.Arrays;

/**
 *
 * @author Megan Ostrander
 */
public class Node {
    
    Listing data;
    Node left, right;
    
    //in case no information is passed to the class constructor for listing!
    Node()
    {
        data = null;
        left = right = null;
    }
    
    
    Node(String listing)
    {
        data = new Listing(listing);
        left = right = null;
    }
    
    
    Node(Listing listing)
    {
        data = listing;
        left = right = null;
    }
    
    
    
    public String getData()
    {
        return data.getKey();
    }
    
    
}
