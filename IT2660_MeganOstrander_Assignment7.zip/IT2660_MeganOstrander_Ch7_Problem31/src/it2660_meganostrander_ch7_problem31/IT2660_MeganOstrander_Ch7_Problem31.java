/*
 * A program that uses a switch statement to determine which options the user 
 *      wants to use while creating a binary tree, adding, updating, or 
 *      deleting values in the tree. Classes are copied from ch 7 problem 30
 *      project.
 */
package it2660_meganostrander_ch7_problem31;

import java.util.Scanner;

/**
 *
 * @author Megan Ostrander
 */
public class IT2660_MeganOstrander_Ch7_Problem31 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner keyboard = new Scanner(System.in);
        keyboard.useDelimiter("\n");
        
        BinaryTree classroom = null; //initialized with values later
        
        System.out.println("Please enter the number of initial student entries: ");
        int reply = keyboard.nextInt();
        
        //if value of reply is 0 or less than 0, ask for new number
        if(reply == 0 || reply < 0)
        {
            System.out.println("Cannot create a binary tree without any entries!"
                    + "\nPlease enter a new positive value: ");
            reply = keyboard.nextInt();
        }
        
        //assignment to self allows program to use following if statements after
        //reassignment (if previous attempt was less than 1).
        reply = reply;
        
        //if value of reply is 1, create blank listing object and ask for input
        //send listing object to binartTree(listing) constructor
        if(reply == 1)
        {
            System.out.println("Please enter the student's information: ");
            Listing student = new Listing();
            
            student.manualInput();
            
            System.out.println("Creating the binary tree with 1 value...");
            
            classroom = new BinaryTree(student);
            
        }
        //if more than 1 value but less than 10, then create array of values
        //and send array to BinaryTree(array).
        else if(reply > 1 && reply < 10)
        {
            Listing [] students = new Listing[reply];
            Listing student;
            
            
            for(int i = 0; i < students.length; i++)
            {
               System.out.println("Please enter student " + (i + 1) + "'s information: "); 
               student = new Listing();
               student.manualInput();
               
               students[i] = student;
            }
            
            System.out.println("Creating the binary tree with " + reply + " values...");
            
            classroom = new BinaryTree(students);
        }
        //if more than 10 values, create array, determine length and divide by 10,
        //send information to BinaryTree(array, division) WHERE division is 
        //the result of array.length / 10.
        else if(reply >= 10)
        {
            Listing [] students = new Listing[reply];
            Listing student;
            
            
            for(int i = 0; i < students.length; i++)
            {
               System.out.println("Please enter student " + i + "'s information: "); 
               student = new Listing();
               student.manualInput();
               students[i] = student;
            }
            
            int divide = students.length / 10;
            
            System.out.println("Creating the binary tree with " + reply + " values...");
            
            classroom = new BinaryTree(students, divide);
        }
        
        System.out.println("Welcome to your classroom student list program."
                + "\nPlease enter one of the following numbers to continue:"
                + "\n1. Add new value to the list."
                + "\n2. Delete an existing value in the list."
                + "\n3. Update an existing value in the list."
                + "\n4. Print student list."
                + "\n5. Exit");
        
        reply = keyboard.nextInt();
        
        //objects used in while/switch loops
        Listing student;
        
        while (reply != 5)
        {
            switch(reply)
            {
                case 1: //add value to binary tree
                    System.out.println("Please enter the student's information: "); 
                    student = new Listing();
                    student.manualInput();
                    
                    classroom.insertNode(classroom.root, student);
                    
                    break;
                    
                case 2: //remove value from binary tree
                    System.out.println("Please enter the name of student to remove:");
                    String name = keyboard.next();
                    
                    classroom.delete(name);
                    
                    break;
                    
                case 3: //update value in binary tree
                    System.out.println("Please enter the name of student "
                            + "to be updated:");
                    name = keyboard.next();
                    
                    System.out.println("Enter the new student information: ");
                    student = new Listing();
                    student.manualInput();
                    
                    System.out.println("Updating " + name + " now...");
                    classroom.updateTree(classroom.root, name, student);
                    break;
                    
                case 4: //print binary tree
                    System.out.println("Printing the student list now...");
                    classroom.printTree();
                    break;
                    
                case 5: //exit program
                    System.out.println("Ending the program. Thank you.");
                    System.exit(0);
                    break;
                    
                default:
                    System.out.println("Invalid input. Please try again.");
                    break;
            } //end of switch
            
            System.out.println(
                "\nPlease enter one of the following numbers to continue:"
                + "\n1. Add new value to the list."
                + "\n2. Delete an existing value in the list."
                + "\n3. Update an existing value in the list."
                + "\n4. Print student list."
                + "\n5. Exit");
            reply = keyboard.nextInt();
            
        } //end of while loop
        
        
        
        
        
    } //end of main method
    
}
