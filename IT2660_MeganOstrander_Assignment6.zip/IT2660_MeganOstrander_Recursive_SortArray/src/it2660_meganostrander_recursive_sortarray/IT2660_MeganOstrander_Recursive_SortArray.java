/*
 * to create an array of 100 randomly inputed numbers and sort them in increasing
 *          order by using a recursive merge sort method. Divides the array by 2
 *          every time until it reaches a length of 1 in both runs, then 
 *          merges the 2 runs back together as it stores the now sorted numbers
 *          into a second array (that is a copy of the original, replacing the 
 *          values as needed.
 */
package it2660_meganostrander_recursive_sortarray;

/**
 *
 * @author Megan Ostrander
 */

import java.util.Random;
import java.util.Arrays;

public class IT2660_MeganOstrander_Recursive_SortArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // Create an array of 100 integers
        Integer a[] = new Integer[100]; 
        
        Random rand = new Random();  // Generate the instance of the Random class        
        
        // Put 100 random numbers into the array
        for(int x=0;x<100;x++)
        {
            a[x] = rand.nextInt(1000);
        }        
        
        System.out.println("Unsorted Array: "+Arrays.toString(a));

        //Call merge sort
        TopDownSplitMerge(a);
         
        //Check the output which is sorted array
        System.out.println("Sorted Array: "+Arrays.toString(a));
    }
    
    
    public static Integer[] TopDownSplitMerge(Integer list[])             
    {
        //If list is empty; no need to do anything
        if (list.length <= 1) {
            return list;
        }
         
        //System.out.println("List before dividing...");
        //System.out.println(Arrays.toString(list) +"\n");
        
        //Split the array in half in two parts
        Integer[] first = new Integer[list.length / 2];
        Integer[] second = new Integer[list.length - first.length];
        

        // Uses System.arraycopy to copy the array.
        System.arraycopy(list, 0, first, 0, first.length);
        System.arraycopy(list, first.length, second, 0, second.length);
         
        //Sort each half recursively
        TopDownSplitMerge(first);
        TopDownSplitMerge(second);
         
        //Merge both halves together, overwriting to original array
        TopDownMerge(first, second, list);
        return list;
    }
     
    private static void TopDownMerge(Integer first[], Integer second[], Integer result[])             
    {
        //Index Position in first array - starting with first element
        int iFirst = 0;
         
        //Index Position in second array - starting with first element
        int iSecond = 0;
         
        //Index Position in merged array - starting with first position
        int iMerged = 0;
         
        //Compare elements at iFirst and iSecond, 
        //and move smaller element at iMerged
        while (iFirst < first.length && iSecond < second.length) 
        {
            if (first[iFirst].compareTo(second[iSecond]) < 0) 
            {
                result[iMerged] = first[iFirst];
                iFirst++;
            } 
            else
            {
                result[iMerged] = second[iSecond];
                iSecond++;
            }
            iMerged++;
            //System.out.println("Printing current result list...");
            //System.out.println(Arrays.toString(result) +"\n");
        }
        //copy remaining elements from both halves - each half will have already sorted elements
        System.arraycopy(first, iFirst, result, iMerged, first.length - iFirst);
        System.arraycopy(second, iSecond, result, iMerged, second.length - iSecond);
    }
    
} // end of program
